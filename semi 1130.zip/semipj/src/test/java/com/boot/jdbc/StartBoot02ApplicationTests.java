package com.boot.jdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StartBoot02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
